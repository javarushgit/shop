package org.example.decorator;

public abstract class House
{

    String info;
    public String getInfo()
    {
        return info;
    }
    public abstract int getPrice();
}
