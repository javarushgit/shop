package org.example.decorator;

public class Italian extends Person
{
    @Override
    public String getClothes() {
        return "Jacket ";
    }
}
