package org.example.decorator;

public abstract class Person {
    public abstract String getClothes();
}
