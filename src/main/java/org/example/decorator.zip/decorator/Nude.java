package org.example.decorator;

public class Nude extends Person
{
    @Override
    public String getClothes() {
        return "";
    }
}
