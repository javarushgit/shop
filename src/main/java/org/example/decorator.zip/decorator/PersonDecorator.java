package org.example.decorator;

public abstract class PersonDecorator extends Person
{
    Person person;

}
